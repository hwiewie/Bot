
/!\ IF YOU NEED ANY HELP TO CONFIGURE THE BOT PROPERLY, JUST CONNECT TO THE FORUM WITH A VALID USERNAME AND ASK YOUR QUESTION TO THE 
MINI-CHAT =) /!\

DISCLAIMER
Be aware that using this bot is against the user-term agreement that you made with GGG to play this game and it may lead your account to be banned.

HOW TO USE
First of all, for some obvious reasons, DO NOT USE IT ON YOUR MAIN ACCOUNT NOR ON HARDCORE CHARACTER!!
If you are experiencing trouble, you can check Pronooooob awesome Compendium : https://exiled-bot.net/community/index.php/topic/1682-guide-for-beginners-exiledbot-compendium/#

BE CAREFUL !! Botting more than 8h per day will most probably get you banned. If you want to feel safe, do short botting sessions and never bot longer than 4h on same account / mac address / ip.

IMPORTANT : You need to install DirectX End-User Runtime. You can download it here : http://www.microsoft.com/en-us/download/details.aspx?id=35
IMPORTANT : Be sure that the keys bound are the default one in game.

1) Run the bot in admin mode. Then you need to select a process where to inject it. It can basically be any x86 process, the process needs to be RUNNED IN ADMIN MODE !!.
2) Once bot is attached and GUI pop, configure parameters. You can check config.ini, skills.ini and pickit.ini files for more infos, everything is pretty self-explenatory or you can read the comments when it's not.
3) You don't understand how something works? Hover your mouse over it and you'll get some informations!
4) Launch the game.
5) IMPORTANT : Put the game in 800x600 resolution windowed. 
6) IMPORTANT : "Close all panels" key needs to be bound on SPACE (default).
7) To make the gem leveling work, you need to disable the "Quest Tracking" (Options/UI).
8) To avoid picking thrash items, you should enable the "Key Pickup" option and disable the "Always Highlight" (Options/UI).
9) Start the bot, it should log and enter in the specified zone.
10) Have fun =)
11) Pause and unpause the bot by pressing F12
12) You can reload your ini file during runtime as well by pressing F11

For Garena TW users, see : https://exiled-bot.net/community/index.php/topic/3329-%E5%A6%82%E4%BD%95%E6%8A%8A-poe-%E6%94%B9%E7%82%BA%E8%8B%B1%E6%96%87%E7%89%88/
For Garena TH users, see : https://exiled-bot.net/community/index.php/topic/4901-pls-add-poe-thai-server-to-list/#entry27977
For Garena CIS users, see : https://exiled-bot.net/community/index.php/topic/4709-how-to-launch-garena-cis-in-english/

Official Site : http://www.exiled-bot.net/
Official Forum : http://www.exiled-bot.net/community/
Lastest Release : http://exiled-bot.net/#download

